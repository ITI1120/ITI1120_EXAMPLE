class Point(object):
    ''' Geometric point'''
    def __init__(self, x =0, y =0, col="red"):
        '''(Point, int, int, str)-> None'''
        self.x = x
        self.y = y
        self.color = col

    def __repr__(self):
      '''(Point)-> str'''  
      return "Xpt: " + str(self.x) + " Ypt: " + str(self.y) + " Color: " + self.color

    def __eq__(self, other):
        '''(Point,Point)->bool'''
        return self.x == other.x and self.y == other.y and self.color == other.color
    
    def display(self):
        '''(Point)-> None'''
        print("X:",self.x,"; Y:",self.y,"; Color:",self.color)

class Rectangle(object):
    ''' rectangle'''
    def __init__(self, coin, len, height):
       '''(Rectangle, Point, int, int)-> None'''
       # coin = point of rectangle in the upper left
       self.coin = coin
       self.len = len
       self.height = height

    def info(self):
      '''(Rectangle)-> str'''  
      return str(self.coin) + "; length " + str(self.len) + "; Height " + str(self.height)

    def equivRect(self, other):
      '''(Point,Point)->bool'''
      return self.coin == other.coin and self.len == other.len and self.height == other.height

    def getMiddle(self):
       '''(Rectangle)-> Point '''
       p = Point()
       p.x = self.coin.x + self.len/2
       p.y = self.coin.y - self.height/2
       return p
       
    
    def getArea(self):
        '''(Rectangle) -> int'''
        return self.len * self.height

    def inTheRect(self, pt):
        return pt.x >= self.coin.x and pt.x <= self.coin.x + self.len and pt.y <= self.coin.y and pt.y >= self.coin.y - self.height
            
        
        
