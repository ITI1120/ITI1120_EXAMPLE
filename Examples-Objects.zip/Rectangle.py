class Rectangle(object):
   ''' Geometric rectangle '''

   def __init__(self, height = 0, length = 0):
      self.height = height
      self.length = length
   
   def area(self):
      return self.height * self.length
   
   def display(self):
      print("The height is ", self.height)
      print("The length is; ",self.length)
      #area = self.area()
      print("the area is ", self.area())
