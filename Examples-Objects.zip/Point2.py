class Point(object):
   ''' Geometric point '''

   def __init__(self, x =0, y =0, color = "red"):
      self.x = x
      self.y = y
      self.color = color

   def equivalent(self, other):
      '''(Point,Point)->bool self == other if the position and the color are the same'''
      return self.x == other.x and self.y == other.y and self.color == other.color

   
   def display(self):
      print("X = ",self.x,"; Y = ",self.y, "; Color = ", self.color)
