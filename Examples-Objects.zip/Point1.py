class Point(object):
   ''' Geometric point '''
   def display(self):
      print("X = ",self.x,"; Y = ",self.y, "; Color = ", self.color)
