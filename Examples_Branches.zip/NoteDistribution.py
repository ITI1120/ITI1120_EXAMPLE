def NoteDistribution():
  
  s = input("Please enter a note between 0 and 100: ")
  n = float(s)
  
  if(n<0 or n>100):
    print("The note entered is either negative or > 100,")
    print("it is thus not valid")
  elif(n >=90):
    print("The note corresponds to A+")
  elif(n>=85):
    print("The note corresponds to A")
  elif(n>=80) :
    print("The note corresponds to A-")
  elif(n>=75) :
    print("The note corresponds to B+")
  elif(n>=70) :
    print("The note corresponds to B")
  elif(n>=65) :
    print("The note corresponds to C+")
  elif(n>=60) :
    print("The note corresponds to C")
  elif(n>=55) :
    print("The note corresponds to D+")
  elif(n>=50) :
    print("The note corresponds to D")
  elif(n>=40) :
    print("The note corresponds to E")
  else :
    print("The note corresponds to F")
      

 


