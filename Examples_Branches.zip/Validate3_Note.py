def Validate3_Note():
  
  s = input("Please enter a note between 0 and 100: ")
  n = float(s)
  
  if(n>=0 and n<=100):
    print("The entered note is valid")
  else:
    print("The entered note is either negative or > 100, it is thus not valid")

 


