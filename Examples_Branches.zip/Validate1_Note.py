def Validate1_Note():

  note = float( input("Enter a note between 0 and 100: "))              
                
  if(note<0):
    print("The entered note is negative!")
    print("it is thus not valid")

  elif(note>100):
    print("The note entered is > 100,")
    print("it is thus not valid")

  else:
    print("the note is valid")





  

 


