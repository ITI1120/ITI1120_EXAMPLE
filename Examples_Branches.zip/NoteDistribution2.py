def NoteDistribution2():

  def totalNote(ex1, ex2, hw):
    return (ex1+ex2+hw)/3

  final = float(input("Please enter your final: "))
  midterm = float(input("Please enter your midterm: "))
  hwAvg = final = float(input("Please enter your HW average: "))
    
  n = totalNote(final, midterm, hwAvg)

  print("Your class note is: ", n)
  if(n >=90):
    print("The note corresponds to A+")
  elif(n>=85):
    print("The note corresponds to A")
  elif(n>=80) :
    print("The note corresponds to A-")
  elif(n>=75) :
    print("The note corresponds to B+")
  elif(n>=70) :
    print("The note corresponds to B")
  elif(n>=65) :
    print("The note corresponds to C+")
  elif(n>=60) :
    print("The note corresponds to C")
  elif(n>=55) :
    print("The note corresponds to D+")
  elif(n>=50) :
    print("The note corresponds to D")
  elif(n>=40) :
    print("The note corresponds to E")
  else :
    print("The note corresponds to F")


  
      

 


