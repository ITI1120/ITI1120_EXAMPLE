# On the console -->a = 10

def increase():
    global a
    a = a+1
    print(a)

#def TestCroit2():
    #croit()
    
    #On the console: increase()




    


                
