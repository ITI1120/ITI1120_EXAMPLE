def TestIncrease1():
    nb = int(input("Enter a number: "))
    increase(nb)

def increase(a):
    a = a+1
    print(a)





    


                
