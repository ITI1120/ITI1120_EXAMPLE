def multiplicationTable(base, start, end):
    print('Fragment of the multiplication table by',base,':')
    for i in range(start, end+1):
        print(i, 'x', base, '=', i*base)
    print()



    


                
