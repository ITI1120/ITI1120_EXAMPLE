def operations(marks):

    #Derivation of the sum and max/min
    sum = marks[0]
    max = marks[0]
    min = marks[0]
    for index in range(1, len(marks)):
        sum = sum + marks[index]
        if marks[index] > max:
            max = marks[index]
        if marks[index] < min:
            min = marks[index]

    print()
    print("the sums of the array is: ", sum)

    print()
    print("The average of the array is: ", sum/len(marks))

    print()
    print("The max of the array is: ", max)

    print()
    print("The min of the array is: ", min)
