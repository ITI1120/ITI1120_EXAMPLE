def occurence(mat, val):

    for nb in range(len(mat)):
        if mat[nb] == val:
            print('position =', nb+1)
            return True
    
    return False

