def positions(mat, val):
    #Looking for a number in the array
    #If found return its position(s)

    position = []
    for index in range(0, len(mat)):
        if mat[index] == val:
            position.append(index)

    if(len(position) == 0):
        print(val,'does not exist in the array')
    else:
        if(len(position) < 2):
            print(val,"exists at the following index")
        else:
            print(val,"exists st the following indexes")

        for index in range(len(position)):
            print(position[index], end=" ")

