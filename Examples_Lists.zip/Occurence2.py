def occurence2(mat, val):
    res = False
    for nb in range(len(mat)):
        
        if mat[nb] == val:
            res = True
            break
    print('Index =', nb)
    return res
