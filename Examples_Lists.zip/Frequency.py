def frequency(mat, val):

    "Count the number occurences of val in mat"
    total = 0
    for index in range(len(mat)):
        if mat[index] == val:
            total = total + 1
            
    return total

    
