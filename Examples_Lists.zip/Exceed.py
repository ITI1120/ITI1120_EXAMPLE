def exceed(mat, val):

    "Returns True if the elements sum exceed v"
    sum = 0
    for index in range(0, len(mat)):
        sum = sum + mat[index]
    
    return sum > val

    
