def operations(marks):

    for index in range(0, len(marks)):
       print(marks[index], end=' ')

    sum = 0
    for index in range(len(marks)):
        sum = sum + marks[index]

    #Derivation of max
    max = marks[0]
    for index in range(1, len(marks)):
        if marks[index] > max:
            max = marks[index]

    #Derivation of min
    min = marks[0]
    for index in range(1, len(marks)):
        if marks[index] < min:
            min = marks[index]

    print()
    print("The sums of the array is: ", sum)

    print()
    print("The average in the array is ", sum/len(marks))

    print()
    print("The max of the array is: ", max)

    print()
    print("The min of the array is: ", min)
