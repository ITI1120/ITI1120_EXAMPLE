def duplicata(mat):
    #Look for any duplicata
    for index in range(len(mat)-1):
        nb = mat[index]
        for index2 in range(index+1,len(mat)):
            if nb == mat[index2]:
                return True #Does not need to go further

    return False


                
