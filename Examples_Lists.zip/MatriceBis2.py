def operations(marks):

    #Derivation of the sum and max/min
    sum = marks[0]
    max = marks[0]
    min = marks[0]
    for index in range(1, len(marks)):
        sum = sum + marks[index]
        if marks[index] > max:
            max = marks[index]
        if marks[index] < min:
            min = marks[index]

    result = []
    
    result.append(sum)
    result.append(max)
    result.append(min)
    result.append(sum/len(marks))

    return result

