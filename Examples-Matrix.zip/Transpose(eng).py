#Declare an empty matrix prior to calling this function: m = []
def transpose(mat) :

    m = int(input("Enter the number of rows: "))
    n = int(input("Enter the number of columns: "))

    build(mat, m,n)
    display(mat)
    rebuild(mat)
    print()
    display(mat)

def build(mat, m, n):
    import random
    for row in range(m):
        mat.append([]) #create an empty row
        for col in range(n):
            mat[row].append(random.randint(0, 20))

def display(mat):
    for row in mat:
        for col in row:
            print(col, end=" ")
        print()

def rebuild(mat):
    for row in range(len(mat)):
        col = row +1
        while col<len(mat):
            if col != row:
                temp = mat[row][col]
                mat[row][col] = mat[col][row]
                mat[col][row] = temp
            col +=1

def rebuild2(mat):
    for row in range(len(mat)):
        for col in range(row +1, len(mat)):
            if col != row:
                temp = mat[row][col]
                mat[row][col] = mat[col][row]
                mat[col][row] = temp


            
            







        


            
    
    

